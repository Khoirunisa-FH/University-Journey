package com.example.aplikasisavenama;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.*;

public class MainActivity extends AppCompatActivity {

    EditText editText;
    Button buttonSave, buttonRead, buttonUpdate, buttonDelete;
    String fileName = "contohfile.txt";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText = findViewById(R.id.editText);
        buttonSave = findViewById(R.id.buttonSave);
        buttonRead = findViewById(R.id.buttonRead);
        buttonUpdate = findViewById(R.id.buttonUpdate);
        buttonDelete = findViewById(R.id.buttonDelete);

        buttonSave.setOnClickListener(view -> saveToFile());
        buttonRead.setOnClickListener(view -> readFromFile());
        buttonUpdate.setOnClickListener(view -> updateFile());
        buttonDelete.setOnClickListener(view -> deleteFile());
    }

    private void saveToFile() {
        String text = editText.getText().toString();
        try (FileOutputStream fos = openFileOutput(fileName, MODE_PRIVATE)) {
            fos.write(text.getBytes());
            Toast.makeText(this, "Data disimpan", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void readFromFile() {
        try (FileInputStream fis = openFileInput(fileName)) {
            BufferedReader reader = new BufferedReader(new InputStreamReader(fis));
            StringBuilder builder = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                builder.append(line).append("\n");
            }
            editText.setText(builder.toString().trim());
            Toast.makeText(this, "Data dibaca", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            Toast.makeText(this, "Gagal membaca file", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateFile() {
        String newText = editText.getText().toString();
        try (FileOutputStream fos = openFileOutput(fileName, MODE_PRIVATE)) {
            fos.write(newText.getBytes());
            Toast.makeText(this, "File diubah", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            Toast.makeText(this, "Gagal mengubah file", Toast.LENGTH_SHORT).show();
        }
    }

    private void deleteFile() {
        File dir = getFilesDir();
        File file = new File(dir, fileName);
        if (file.exists()) {
            if (file.delete()) {
                editText.setText("");
                Toast.makeText(this, "File dihapus", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Gagal menghapus file", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "File tidak ditemukan", Toast.LENGTH_SHORT).show();
        }
    }
}
