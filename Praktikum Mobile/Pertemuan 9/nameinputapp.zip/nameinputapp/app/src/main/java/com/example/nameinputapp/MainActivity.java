package com.example.nameinputapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    private EditText editTextName;
    private Button buttonSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Enable edge-to-edge display
        EdgeToEdge.enable(this);

        setContentView(R.layout.activity_main);

        // Handle system insets for edge-to-edge display
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main_layout), (v, windowInsets) -> {
            Insets insets = windowInsets.getInsets(WindowInsetsCompat.Type.systemBars());
            // Adjust layout margins or padding based on system insets if needed
            return WindowInsetsCompat.CONSUMED;
        });

        // Initialize views
        editTextName = findViewById(R.id.editTextName);
        buttonSave = findViewById(R.id.buttonSave);

        // Set click listener for save button
        buttonSave.setOnClickListener(v -> {
            // Get the name from EditText
            String name = editTextName.getText().toString().trim();

            // Validate input
            if (!name.isEmpty()) {
                // Create intent to move to SuccessActivity
                Intent intent = new Intent(MainActivity.this, SuccessActivity.class);
                intent.putExtra("USER_NAME", name);
                startActivity(intent);
                finish(); // Close the current activity
            } else {
                // Show error if name is empty
                Toast.makeText(MainActivity.this, "Please enter your name", Toast.LENGTH_SHORT).show();
            }
        });
    }
}