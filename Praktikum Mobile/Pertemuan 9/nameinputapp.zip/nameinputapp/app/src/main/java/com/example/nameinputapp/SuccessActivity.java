package com.example.nameinputapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SuccessActivity extends AppCompatActivity {
    private TextView textViewName;
    private Button buttonBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Enable edge-to-edge display
        EdgeToEdge.enable(this);

        setContentView(R.layout.activity_success);

        // Handle system insets for edge-to-edge display
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.success_layout), (v, windowInsets) -> {
            Insets insets = windowInsets.getInsets(WindowInsetsCompat.Type.systemBars());
            // Adjust layout margins or padding based on system insets if needed
            return WindowInsetsCompat.CONSUMED;
        });

        // Initialize views
        textViewName = findViewById(R.id.textViewName);
        buttonBack = findViewById(R.id.buttonBack);

        // Retrieve name from intent
        String userName = getIntent().getStringExtra("USER_NAME");
        if (userName == null) {
            userName = "User";
        }

        // Set name in TextView
        textViewName.setText(String.format("Hello, %s", userName));

        // Set click listener for back button
        buttonBack.setOnClickListener(v -> {
            // Create intent to go back to MainActivity
            Intent intent = new Intent(SuccessActivity.this, MainActivity.class);
            startActivity(intent);
            finish(); // Close the current activity
        });
    }
}